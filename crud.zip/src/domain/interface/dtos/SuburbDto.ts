export interface SuburbDto{
    name:string
    state:string
    postcode:number
}